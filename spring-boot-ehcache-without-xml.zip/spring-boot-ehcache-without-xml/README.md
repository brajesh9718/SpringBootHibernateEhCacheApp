# Spring Boot Ehcache Configuration Without XML or JavaConfig

This application cover below point on spring boot application for ehcache configuration.

1) Implment ehcache configuration without xml
2) How to update ehcache data dynamically

   [Click here for step by step guide](../../wiki)
